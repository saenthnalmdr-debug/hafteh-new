package ir.hafteh.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

private val ink = Color(0xFF24272B)
private val line = Color(0xFFD8DCE1)
private val palette = listOf(Color(0xFFB9D8F5), Color(0xFFF5D49B), Color(0xFFC8E5C7), Color(0xFFE8C8E8), Color(0xFFF2BFC0), Color(0xFFC9D0F4))

data class Plan(val day: Int, val start: Int, val end: Int, val title: String, val color: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HaftehApp() }
    }
}

@Composable
fun HaftehApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("hafteh", 0) }
    val plans = remember {
        mutableStateListOf<Plan>().apply {
            val raw = prefs.getString("plans", "[]") ?: "[]"
            runCatching {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Plan(o.getInt("d"), o.getInt("s"), o.getInt("e"), o.getString("t"), o.getInt("c")))
                }
            }
        }
    }
    var weekOffset by remember { mutableIntStateOf(0) }
    var dark by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    var editIndex by remember { mutableIntStateOf(-1) }
    var pickedDay by remember { mutableIntStateOf(0) }
    var pickedStart by remember { mutableIntStateOf(18) } // 09:00
    var pickedEnd by remember { mutableIntStateOf(22) }   // 11:00
    var title by remember { mutableStateOf("") }
    var pickedColor by remember { mutableIntStateOf(0) }

    fun save() {
        val a = JSONArray()
        plans.forEach { p -> a.put(JSONObject().put("d",p.day).put("s",p.start).put("e",p.end).put("t",p.title).put("c",p.color)) }
        prefs.edit().putString("plans", a.toString()).apply()
    }

    val bg = if (dark) Color(0xFF17191D) else Color(0xFFFAFAFA)
    val surface = if (dark) Color(0xFF24272D) else Color.White
    val fg = if (dark) Color(0xFFF2F2F2) else ink
    val days = listOf("شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه")
    val weekLabel = jalaliWeekLabel(weekOffset)

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 10.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("برنامه هفتگی", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(weekLabel, color = fg.copy(alpha=.7f), fontSize = 13.sp)
                }
                TextButton(onClick = { weekOffset-- }) { Text("‹", fontSize = 26.sp, color = fg) }
                TextButton(onClick = { weekOffset = 0 }) { Text("امروز", color = fg) }
                TextButton(onClick = { weekOffset++ }) { Text("›", fontSize = 26.sp, color = fg) }
                TextButton(onClick = { dark = !dark }) { Text(if (dark) "☀" else "☾", color = fg, fontSize = 20.sp) }
            }
            Text("برای ساخت برنامه، روی جدول از ساعت شروع تا پایان بکشید", color = fg.copy(alpha=.65f), fontSize = 11.sp, modifier = Modifier.padding(bottom=8.dp))
            ScheduleGrid(
                days = days, plans = plans.toList(), surface = surface, foreground = fg, gridLine = line,
                onCreate = { d, s, e ->
                    pickedDay=d; pickedStart=s; pickedEnd=e.coerceAtLeast(s+1)
                    title=""; pickedColor=0; editIndex=-1; dialog=true
                },
                onEdit = { idx ->
                    val p=plans[idx]; pickedDay=p.day; pickedStart=p.start; pickedEnd=p.end
                    title=p.title; pickedColor=p.color; editIndex=idx; dialog=true
                }
            )
            Spacer(Modifier.height(8.dp))
            Text("نکته: هر خانه ۳۰ دقیقه است؛ بلوک رنگی با کشیدن انگشت، چند خانه را یکجا می‌پوشاند.", color=fg.copy(alpha=.65f), fontSize=10.sp)
        }
        if (dialog) {
            AlertDialog(
                onDismissRequest = { dialog=false },
                title = { Text(if (editIndex>=0) "ویرایش برنامه" else "برنامه جدید") },
                text = {
                    Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value=title, onValueChange={title=it}, label={Text("عنوان برنامه")}, singleLine=true)
                        Text("${days[pickedDay]}  •  ${timeText(pickedStart)} تا ${timeText(pickedEnd)}", fontSize=13.sp)
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text("شروع", modifier=Modifier.weight(1f))
                            Stepper(value=pickedStart, min=0, max=27, onChange={v -> pickedStart=v; if(pickedEnd<=v) pickedEnd=v+1})
                            Text("پایان", modifier=Modifier.weight(1f))
                            Stepper(value=pickedEnd, min=pickedStart+1, max=28, onChange={pickedEnd=it})
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            palette.forEachIndexed { i,c ->
                                Box(Modifier.size(30.dp).background(c, RoundedCornerShape(7.dp)).border(if(i==pickedColor) 2.dp else 0.dp, if(i==pickedColor) Color.Black else Color.Transparent, RoundedCornerShape(7.dp)).pointerInput(i){detectTapGestures{pickedColor=i}})
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick={
                        if(title.isNotBlank()) {
                            val p=Plan(pickedDay,pickedStart,pickedEnd,title,pickedColor)
                            if(editIndex>=0) plans[editIndex]=p else plans.add(p)
                            save()
                        }
                        dialog=false
                    }) { Text("ذخیره") }
                },
                dismissButton = {
                    Row {
                        if(editIndex>=0) TextButton(onClick={plans.removeAt(editIndex); save(); dialog=false}) { Text("حذف", color=Color.Red) }
                        TextButton(onClick={dialog=false}) { Text("انصراف") }
                    }
                }
            )
        }
    }
}

@Composable
fun Stepper(value:Int, min:Int, max:Int, onChange:(Int)->Unit) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        TextButton(onClick={onChange((value-1).coerceAtLeast(min))}, contentPadding=PaddingValues(3.dp)) { Text("−", fontSize=20.sp) }
        Text(timeText(value), fontSize=12.sp)
        TextButton(onClick={onChange((value+1).coerceAtMost(max))}, contentPadding=PaddingValues(3.dp)) { Text("+", fontSize=20.sp) }
    }
}

@Composable
fun ScheduleGrid(
    days:List<String>, plans:List<Plan>, surface:Color, foreground:Color, gridLine:Color,
    onCreate:(Int,Int,Int)->Unit, onEdit:(Int)->Unit
) {
    val scroll= rememberScrollState()
    val rowH=31.dp
    val headerH=42.dp
    val timeW=48.dp
    val dayW=68.dp
    val totalRows=28 // 08:00–22:00, half-hour intervals
    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        Row {
            Box(Modifier.width(timeW).height(headerH), contentAlignment=Alignment.Center) { Text("ساعت", color=foreground, fontSize=10.sp) }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                days.forEach { d ->
                    Box(Modifier.width(dayW).height(headerH).background(surface).border(0.5.dp,gridLine), contentAlignment=Alignment.Center) {
                        Text(d, color=foreground, fontSize=10.sp, fontWeight=FontWeight.SemiBold)
                    }
                }
            }
        }
        Row {
            Column {
                repeat(totalRows) { r ->
                    Box(Modifier.width(timeW).height(rowH), contentAlignment=Alignment.TopCenter) {
                        if(r%2==0) Text(String.format("%02d:00",8+r/2), color=foreground.copy(alpha=.8f), fontSize=10.sp)
                        else Text("۳۰", color=foreground.copy(alpha=.35f), fontSize=8.sp)
                    }
                }
            }
            BoxWithConstraints(Modifier.horizontalScroll(rememberScrollState())) {
                val width=dayW*7
                val height=rowH*totalRows
                Box(Modifier.width(width).height(height).background(surface)) {
                    Canvas(Modifier.fillMaxSize()) {
                        val cw=size.width/7f
                        val rh=size.height/totalRows
                        for(i in 0..7) drawLine(gridLine, Offset(i*cw,0f),Offset(i*cw,size.height),1f)
                        for(i in 0..totalRows) drawLine(gridLine,Offset(0f,i*rh),Offset(size.width,i*rh),if(i%2==0)1.1f else .55f)
                    }
                    plans.forEachIndexed { idx,p ->
                        val top=rowH*p.start
                        val h=rowH*(p.end-p.start)
                        Box(
                            Modifier.offset(x=dayW*p.day+2.dp,y=top+2.dp)
                                .width(dayW-4.dp).height(h-4.dp)
                                .background(palette[p.color.coerceIn(0,palette.lastIndex)],RoundedCornerShape(4.dp))
                                .pointerInput(idx){detectTapGestures{onEdit(idx)}}
                                .padding(3.dp),
                            contentAlignment=Alignment.Center
                        ) {
                            Text(p.title+"\n${timeText(p.start)}–${timeText(p.end)}", color=Color(0xFF24313D), fontSize=9.sp, textAlign=TextAlign.Center, lineHeight=11.sp, fontWeight=FontWeight.Medium)
                        }
                    }
                    var dragStart by remember { mutableStateOf<Offset?>(null) }
                    var dragEnd by remember { mutableStateOf<Offset?>(null) }
                    Box(Modifier.fillMaxSize().pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart={ dragStart=it; dragEnd=it },
                            onDrag={change,delta -> change.consume(); dragEnd=(dragEnd ?: change.position)+delta},
                            onDragEnd={
                                val a=dragStart; val b=dragEnd
                                if(a!=null && b!=null) {
                                    val day=((minOf(a.x,b.x)/size.width)*7).toInt().coerceIn(0,6)
                                    val start=(minOf(a.y,b.y)/size.height*totalRows).toInt().coerceIn(0,27)
                                    val end=((maxOf(a.y,b.y)/size.height*totalRows).toInt()+1).coerceIn(start+1,28)
                                    onCreate(day,start,end)
                                }
                                dragStart=null; dragEnd=null
                            }
                        )
                    })
                }
            }
        }
    }
}

fun timeText(slot:Int):String {
    val mins=8*60+slot*30
    return String.format("%02d:%02d",mins/60,mins%60)
}

// Gregorian-to-Jalali conversion, used only to display the week heading.
fun jalaliWeekLabel(offset:Int):String {
    val c=Calendar.getInstance()
    c.firstDayOfWeek=Calendar.SATURDAY
    c.set(Calendar.DAY_OF_WEEK,Calendar.SATURDAY)
    c.add(Calendar.DAY_OF_YEAR,offset*7)
    val (jy,jm,jd)=gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH))
    return "${fa(jd)} ${listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")[jm-1]} ${fa(jy)}"
}
fun gregorianToJalali(gy:Int,gm:Int,gd:Int):Triple<Int,Int,Int> {
    val gdm=intArrayOf(0,31,if(isLeap(gy))29 else 28,31,30,31,30,31,31,30,31,30,31)
    var gy2=gy-1600; var gm2=gm-1; var gd2=gd-1
    var gdn=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400
    for(i in 0 until gm2) gdn+=gdm[i+1]
    gdn+=gd2
    var jdn=gdn-79
    val jnp=jdn/12053; jdn%=12053
    var jy=979+33*jnp+4*(jdn/1461); jdn%=1461
    if(jdn>=366){jy+=(jdn-1)/365;jdn=(jdn-1)%365}
    val jm=if(jdn<186) 1+jdn/31 else 7+(jdn-186)/30
    val jd=1+(if(jdn<186) jdn%31 else (jdn-186)%30)
    return Triple(jy,jm,jd)
}
fun isLeap(y:Int)= y%4==0 && (y%100!=0 || y%400==0)
fun fa(n:Int)=n.toString().map { if(it in '0'..'9') ('۰'.code+it.code-'0'.code).toChar() else it }.joinToString("")
